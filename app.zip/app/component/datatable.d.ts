export declare class AppComponent {
    appTitle: string;
}
