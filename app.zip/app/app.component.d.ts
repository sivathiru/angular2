import { Http } from "@angular/http";
export declare class AppComponent {
    private http;
    private data;
    constructor(http: Http);
    private sortByWordLength;
    removeItem(item: any): void;
}
